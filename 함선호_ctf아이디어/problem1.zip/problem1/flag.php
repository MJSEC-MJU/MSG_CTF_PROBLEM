<?php
if(!defined('ALLOW_FLAG_ACCESS')){
 die("Access Denied");
}

$flag= "**fake flag**";
?>
