<?php
$db_username = getenv('DB_USERNAME');
$db_password = getenv('DB_PASSWORD');
$db_name     = getenv('DB_NAME');
$db_host     = getenv('DB_HOST');
$port        = getenv('PORT');
?>
